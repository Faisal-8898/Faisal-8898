return {
	"williamboman/mason.nvim",
	dependencies = {
		"williamboman/mason-lspconfig.nvim",
		"WhoIsSethDaniel/mason-tool-installer.nvim",
	},
	config = function()
		local mason = require("mason")
		local mason_lspconfig = require("mason-lspconfig")
		local mason_tool_installer = require("mason-tool-installer")

		mason.setup({
			ui = {
				icons = {
					package_installed = "✓",
					package_pending = "➜",
					package_uninstalled = "✗",
				},
			},
		})

		mason_lspconfig.setup({
			ensure_installed = {
				-- Your existing servers
				"ts_ls",
				"html",
				"cssls",
				"tailwindcss",
				"svelte",
				"lua_ls",
				"graphql",
				"emmet_ls",
				"prismals",
				"pyright",
				-- Java-related servers
				"jdtls", -- Java language server
				"kotlin_language_server", -- Kotlin language server
				"gradle_ls", -- Gradle language server (supports Kotlin DSL)
				"lemminx", -- XML language server (useful for Spring configurations)
			},
		})

		mason_tool_installer.setup({
			ensure_installed = {
				"prettier", -- prettier formatter
				"stylua", -- lua formatter
				"isort", -- python formatter
				"black", -- python formatter
				"google-java-format", -- java formatter
				"pylint", --python linter
				"eslint_d", -- jslinter
				"checkstyle", --javalinter
				"codelldb",
			},
		})
	end,
}
